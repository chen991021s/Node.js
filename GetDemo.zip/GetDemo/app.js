var http=require('http');
var fs=require('fs');
var url=require('url');
//创建web服务器
var server=http.createServer();
//监听请求
server.on('request',function(requert,respone){
    //url.parse获取路径的所有参数
    //第一个参数是路径，第二给参数是将query中的字符串解析为对象
   var parse= url.parse(requert.url,true);
//    console.log(parse);
   //路径
   var pathname=parse.pathname;
    if(pathname=='/' && requert.method=='GET'){
        fs.readFile('./index.html','utf8',function(error,data){
            respone.end(data);
        })
    }else if(pathname=='/zhuce' && requert.method=='GET'){
            console.log('sussess');
            var array=['xiao','chen','li'];//数组的值
            var my=parse.query.username;//用户输入的值
            //循环判断，是否相同
            for(var i=0;i<=array.length;i++){
                if(array[i]==my){
                    respone.end('0');
                    break;
                }
            }
            respone.end('1');
    }
})
//开启服务
server.listen('8080',function(){
    console.log("http://localhost:8080");
})
